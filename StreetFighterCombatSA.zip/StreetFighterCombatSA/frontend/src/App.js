import React from 'react';

function App() {
    return (
        <div>
            <h1>Welcome to Street Fighter: Combat SA</h1>
            <button>Play Now</button>
        </div>
    );
}

export default App;